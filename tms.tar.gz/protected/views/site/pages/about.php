<?php
$this->pageTitle=Yii::app()->name . ' - About';
$this->breadcrumbs=array(
	'About',
);
?>
<h1>About Trafficone Management Systems</h1>

<p>Developed in 1997, Industrial Systems was the first of its kind in 
artificial corporations: producing the finest in not-for-sale software 
and hardware.  IS grew from a small, one-man operation to an empire of 
one-man operations overnight, with many individuals claiming the IS 
name.  However, in 2007, the mission of IS changed from industrial to 
political, and many individuals who once held the Industrial Systems 
name near and dear, discontinued using the name for fear of being 
"hassled by the man."  Industrial Systems fell apart and the name was 
almost forgotten.</p>  
<p>In 2010, Trafficone Management partnered with the dying Industrial 
Systems to form Trafficone Management Systems.  The next few months 
saw a much needed overhaul of both corporations, one which the public 
greatly appreciated.  Bygone were the days of topless men playing 
beach volleyball to distract customers from the bigger issues, things 
were finally looking up.  As public interest grew, so did the greed of 
Trafficone Management, putting in place advertisements to grow 
revenue.  This was okay, and no one really minded.</p>
<p>Today, Industrial Systems and Trafficone Management are seperate 
entities that work togethter, generating content and products that 
anyone can enjoy.  This partnership will hopefully garner the interest 
of flegeling corperations, in hopes that one day they may become 
purely artificial.</p>
