<?php $this->pageTitle=Yii::app()->name; ?>

<h1>Welcome to <i><?php echo CHtml::encode(Yii::app()->name); ?></i></h1>

<p>Welcome to the central head of IS:TMS.  Please pardon our dust, user 
from <?php echo $_SERVER['REMOTE_ADDR'];?>.</p>


