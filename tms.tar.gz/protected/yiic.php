<?php

// change the following paths if necessary
$yiic=dirname(__FILE__).'/../../yii-1.1.4.r2429/framework/yiic.php';
$config=dirname(__FILE__).'/config/console.php';

require_once($yiic);
